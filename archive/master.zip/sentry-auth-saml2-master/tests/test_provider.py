from sentry.testutils import TestCase


class GenericSAML2ProviderTest(TestCase):
    def test_simple(self):
        pass
